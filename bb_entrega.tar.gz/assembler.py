content = []
import sys



with open(sys.argv[1]) as f:
    content = f.readlines()

content = [x.strip() for x in content]





instruc = {
    "BEQ" : "0001",
    "JMP" : "0010",
    "BGT" : "0011",
    "LOAD" : "0100",
    "STORE" : "0101",
    "XOR" : "0110",
    "NOT" : "0111",
    "OR" : "1000",
    "AND" : "1001",
    "SUB" : "1010",
    "ADD" : "1011",
    "CMP" : "1100"
}

io_pag = { #5 a 3
    "RAM" : "00000",
    "II" : "00100",
    "IO" : "00110"
}

io_addre = { #2 e 0
    "_LOW" : "000",
    "_HIGH" : "001",
    "_MODO" : "010",
    "_BUT" : "011",
    "_H1" : "100",
    "_H2" : "101",
    "_H3" : "110",
    "_H4" : "111",

}

rom = []

for i in content:
    for j in instruc.keys():
        i = i.replace(j, instruc[j])
    for j in io_pag.keys():
        i = i.replace(j, io_pag[j])
    for j in io_addre.keys():
        i = i.replace(j, io_addre[j])
    rom.append(i)
    print(i.split()[-1], i.split()[0])


